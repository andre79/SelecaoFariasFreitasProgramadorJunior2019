#ifndef SELECAOCPPLIBLINUX_H
#define SELECAOCPPLIBLINUX_H

#include <QtCore/qglobal.h>
#include <string>

#if defined(SELECAOCPPLIBLINUX_LIBRARY)
#  define SELECAOCPPLIBLINUXSHARED_EXPORT Q_DECL_EXPORT
#else
#  define SELECAOCPPLIBLINUXSHARED_EXPORT Q_DECL_IMPORT
#endif

class SELECAOCPPLIBLINUXSHARED_EXPORT SelecaoCppLibLinux
{
    std::string msg;
public:
    SelecaoCppLibLinux();
    std::string getMsg();
};

#endif // SELECAOCPPLIBLINUX_H
