#ifndef SELECAOCPPLIBWINDOWS_H
#define SELECAOCPPLIBWINDOWS_H

#include <QtCore/qglobal.h>
#include <string>

#if defined(SELECAOCPPLIBWINDOWS_LIBRARY)
#  define SELECAOCPPLIBWINDOWSSHARED_EXPORT Q_DECL_EXPORT
#else
#  define SELECAOCPPLIBWINDOWSSHARED_EXPORT Q_DECL_IMPORT
#endif

class SELECAOCPPLIBWINDOWSSHARED_EXPORT SelecaoCppLibWindows
{

public:
    SelecaoCppLibWindows();
    std::string getMsg();

protected:
    std::string msg;
};

#endif // SELECAOCPPLIBWINDOWS_H
